package com.example.SmartHouse.Repository.JpaRepoCustom;

import org.springframework.stereotype.Repository;

@Repository
public class UserAccountRepositoryCustom {

    

}
