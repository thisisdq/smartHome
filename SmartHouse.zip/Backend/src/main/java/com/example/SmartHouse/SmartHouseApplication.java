package com.example.SmartHouse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartHouseApplication {
	public static void main(String[] args) {
		SpringApplication.run(SmartHouseApplication.class, args);
	}
}
