import { Component } from '@angular/core';

@Component({
  selector: 'app-device-controller',
  standalone: true,
  imports: [],
  templateUrl: './device-controller.component.html',
  styleUrl: './device-controller.component.scss'
})
export class DeviceControllerComponent {

}
